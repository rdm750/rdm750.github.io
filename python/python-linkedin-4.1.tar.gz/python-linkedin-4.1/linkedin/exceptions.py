# -*- coding: utf-8 -*-
class LinkedInError(Exception):
    pass
